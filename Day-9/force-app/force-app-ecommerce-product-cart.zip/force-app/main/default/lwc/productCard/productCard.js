import { LightningElement, api } from 'lwc';

export default class ProductCard extends LightningElement {
    @api product;

    handleViewDetails() {
        const event = new CustomEvent('productselect', {
            detail: this.product
        });
        this.dispatchEvent(event);
    }

    handleAddToCart() {
        const event = new CustomEvent('addtocart', {
            detail: this.product
        });
        this.dispatchEvent(event);
    }
}
