import { LightningElement, wire } from 'lwc';
import getProducts from '@salesforce/apex/ProductController.getProducts';

export default class ProductList extends LightningElement {
    products;
    error;
    selectedProduct;
    cartItems = [];

    @wire(getProducts)
    wiredProducts({ data, error }) {
        if (data) {
            this.products = data;
            this.error = undefined;
        } else if (error) {
            this.error = error;
            this.products = undefined;
        }
    }

    handleProductSelect(event) {
        this.selectedProduct = event.detail;
    }

    handleAddToCart(event) {
        const product = event.detail;

        const existingItem = this.cartItems.find(
            item => item.product.Id === product.Id
        );

        if (existingItem) {
            this.cartItems = this.cartItems.map(item => {
                if (item.product.Id === product.Id) {
                    return {
                        ...item,
                        quantity: item.quantity + 1
                    };
                }
                return item;
            });
        } else {
            this.cartItems = [
                ...this.cartItems,
                {
                    product: product,
                    quantity: 1
                }
            ];
        }
    }

    handleIncrease(event) {
        const productId = event.target.dataset.id;

        this.cartItems = this.cartItems.map(item => {
            if (item.product.Id === productId) {
                return {
                    ...item,
                    quantity: item.quantity + 1
                };
            }
            return item;
        });
    }

    handleDecrease(event) {
        const productId = event.target.dataset.id;

        this.cartItems = this.cartItems
            .map(item => {
                if (item.product.Id === productId) {
                    return {
                        ...item,
                        quantity: item.quantity - 1
                    };
                }
                return item;
            })
            .filter(item => item.quantity > 0);
    }
}
